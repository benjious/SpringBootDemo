package com.example.demo.dao.shiro;

import com.example.demo.dao.seckill.SeckillDao;
import com.example.demo.entity.shiro.User;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;



@RunWith(SpringRunner.class)
@SpringBootTest
public class ShiroDaoTest {

    @Autowired
    private ShiroDao mShiroDao;
    @Test
    public void findByEmail() throws Exception {
        User user = mShiroDao.findByEmail("893326146@qq.com");
        System.out.println("user : "+user.toString());
    }

}