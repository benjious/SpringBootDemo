package com.example.demo.service.impl;

import com.example.demo.service.MailService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import static org.junit.Assert.*;


@RunWith(SpringRunner.class)
@SpringBootTest
public class MailServiceImplTest {
    @Test
    public void sendHtmlMail() throws Exception {
    }

    @Autowired
    private MailService mMailService;

    @Autowired
    private TemplateEngine mTemplateEngine;

    @Test
    public void sendMail() throws Exception {

        Context context = new Context();
        context.setVariable("id","006");
        String content = mTemplateEngine.process("emialTemplate", context);
        mMailService.sendHtmlMail("1829762004@qq.com","主题：这是模板邮件",content);

    }

}