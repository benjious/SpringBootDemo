package com.example.demo.service.impl;

import com.example.demo.entity.shiro.User;
import com.example.demo.service.ShiroService;
import com.example.demo.util.LogUtil;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.servlet.handler.UserRoleAuthorizationInterceptor;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ShiroServiceImplTest {

    @Autowired
    private ShiroService mShiroService;

    @Test
    public void findByEmail() throws Exception {
        User user = mShiroService.findByEmail("893326146@qq.com");
        LogUtil.getLogger(ShiroServiceImplTest.class).info("========================");
        LogUtil.getLogger(ShiroServiceImplTest.class).info(user.toString());
        LogUtil.getLogger(ShiroServiceImplTest.class).info("========================");

    }

}