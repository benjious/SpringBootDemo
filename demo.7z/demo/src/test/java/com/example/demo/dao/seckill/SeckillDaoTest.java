package com.example.demo.dao.seckill;

import com.example.demo.dao.seckill.SeckillDao;
import com.example.demo.entity.seckill.Seckill;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SeckillDaoTest {

    @Autowired
    private SeckillDao mSeckillDao;
    @Test
    public void reduceNumber() throws Exception {
        int number = mSeckillDao.reduceNumber(1000, new Date());
        System.out.println("reduceNumber : "+number);
    }

    @Test
    public void querySeckillById() throws Exception {
        Seckill seckill = mSeckillDao.querySeckillById(1000l);
        System.out.println("对象："+seckill.toString());
    }

    @Test
    public void queryAllSeckill() throws Exception {
        List<Seckill> seckills = mSeckillDao.queryAllSeckill(0,4);
        for (Seckill seckill :
                seckills) {
            System.out.println("seckill : "+seckill.toString());
        }
    }

    @Test
    public void killByProcedure() throws Exception {

    }

}