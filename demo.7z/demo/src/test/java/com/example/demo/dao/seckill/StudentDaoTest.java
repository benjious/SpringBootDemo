package com.example.demo.dao.seckill;

import com.example.demo.dao.seckill.StudentDao;
import com.example.demo.entity.seckill.Student;
import com.example.demo.entity.seckill.StudentWithList;
import com.example.demo.entity.seckill.StudentWithTeacher;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentDaoTest {
    @Autowired
    private StudentDao mStudentDao;

    @Test
    public void querySingleStudentById() throws Exception {
        Student student = mStudentDao.querySingleStudentById(3);
        System.out.println("单个学生：" + student.toString());
    }

    @Test
    public void querySingleStuByMutlParmas() throws Exception {
        Student student = mStudentDao.querySingleStuByMutlParmas(1, "student1");
        System.out.println("单个学生：" + student.toString());
    }

    @Test
    public void queryAllStudents() throws Exception {
        List<Student> students = mStudentDao.queryAllStudents();
        for (Student student :
                students) {
            System.out.println("所有学生：" + student.toString());
        }
    }

    @Test
    public void queryStuWithListById() throws Exception {
        StudentWithList studentWithList = mStudentDao.queryStuWithListById(4);
        System.out.println("类嵌套List : " + studentWithList.toString());
    }

    @Test
    public void queryInnerStudentById() throws Exception {
        for (int i = 1; i < 7; i++) {
            StudentWithTeacher studentWithTeacher = mStudentDao.queryInnerStudentById(i);
            System.out.println("嵌套类 ：" + studentWithTeacher.toString());
        }
    }

}