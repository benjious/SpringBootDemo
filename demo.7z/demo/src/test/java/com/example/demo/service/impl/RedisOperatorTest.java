package com.example.demo.service.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;



@RunWith(SpringRunner.class)
@SpringBootTest
public class RedisOperatorTest {

    @Autowired
    private StringRedisTemplate mStringRedisTemplate;

    @Test
    public void setValue() throws Exception {
        mStringRedisTemplate.opsForValue().set("mike","OPC",60*10, TimeUnit.SECONDS);
        String value = mStringRedisTemplate.opsForValue().get("mike");
        System.out.println("获取到的值为："+value);
    }

}