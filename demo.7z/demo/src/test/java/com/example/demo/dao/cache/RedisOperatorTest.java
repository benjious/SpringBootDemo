package com.example.demo.dao.cache;

import com.example.demo.entity.seckill.Seckill;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@SpringBootTest
@RunWith(SpringRunner.class)
public class RedisOperatorTest {
    @Autowired
    private RedisOperator mOperator;
    @Test
    public void setSeckill() throws Exception {
        Seckill seckill  =new Seckill();
        seckill.setSeckillId(1000);
        mOperator.putSeckill(seckill);
        Seckill seckill1 = mOperator.getSeckill(seckill.getSeckillId());
        System.out.println("结果为："+seckill1.toString());
    }

}