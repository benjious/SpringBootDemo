package com.example.demo.dao.seckill;

import com.example.demo.dao.seckill.SuccessKilledDao;
import com.example.demo.entity.seckill.Seckill;
import com.example.demo.entity.seckill.SuccessKilled;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SuccessKilledDaoTest {

    @Autowired
    private SuccessKilledDao mSuccessKilledDao;

    @Test
    public void insertSuccessKill() throws Exception {
        int result = mSuccessKilledDao.insertSuccessKill(1000, 1249645646);
        System.out.println("打印插入结果： " + result);
    }

    @Test
    public void querySuccessSeckillById() throws Exception {
        SuccessKilled successKilled  = mSuccessKilledDao.querySuccessSeckillById(1000,1249645646);
        Seckill seckill = successKilled.getSeckill();
        System.out.println("successKilled : "+successKilled);
        System.out.println("seckill" + seckill);
    }

}