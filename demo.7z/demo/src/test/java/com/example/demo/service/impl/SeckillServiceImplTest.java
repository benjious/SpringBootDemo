package com.example.demo.service.impl;

import com.example.demo.dto.Exposer;
import com.example.demo.dto.SeckillExecution;
import com.example.demo.exception.SeckillCloseException;
import com.example.demo.exception.SeckillRepeatException;
import com.example.demo.service.SeckillService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class SeckillServiceImplTest {

    @Autowired
    private SeckillService mSeckillService;



    @Test
    public void getAllSeckill() throws Exception {
    }

    @Test
    public void getSeckillById() throws Exception {

    }


    @Test
    public void exportSecillUrl() throws Exception {
        Exposer exposer = mSeckillService.exportSecillUrl(1002);
        System.out.println("xyz, exposer {} "+exposer);
        if (exposer.isExposer()) {
            try {
                SeckillExecution seckillExecution = mSeckillService.seckillExcution(1000, 13577548556L, "3d5dfe7343ffa92a6128210f50e60c7a");
                System.out.println("xyz, seckillExecution {} "+ seckillExecution);
            } catch (SeckillRepeatException | SeckillCloseException e) {
                throw e;
            }
        }else {
            //秒杀没成功
            System.out.println("xyz1, exposer {}"+exposer);
        }
    }

    @Test
    public void seckillExcution() throws Exception {
    }

    @Test
    public void seckillExcutionProcedure() throws Exception {
    }

}