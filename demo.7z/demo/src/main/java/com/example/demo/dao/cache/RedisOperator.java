package com.example.demo.dao.cache;

import com.example.demo.entity.seckill.Seckill;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

@Component
public class RedisOperator {

    private RedisTemplate<String,Seckill> mTemplate;


    public RedisTemplate<String, Seckill> getTemplate() {
        return mTemplate;
    }

    @Autowired
    public void setTemplate(RedisTemplate<String, Seckill> template) {
        mTemplate = template;
    }

    public void putSeckill(Seckill seckill){
        ValueOperations<String,Seckill> valueOperations =  mTemplate.opsForValue();
        String key = "seckill:" + seckill.getSeckillId();
        valueOperations.set(key,seckill);
    }

    public Seckill getSeckill(long seckillId){
        String key = "seckill:" + seckillId;
        Seckill  seckill  =  mTemplate.opsForValue().get(key);
        System.out.println("redis 中获取的值为： "+seckill + "  key为 ："+seckillId);
        return seckill;
    }
}
