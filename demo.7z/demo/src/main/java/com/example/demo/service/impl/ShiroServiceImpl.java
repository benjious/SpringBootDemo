package com.example.demo.service.impl;

import com.example.demo.dao.shiro.ShiroDao;
import com.example.demo.service.ShiroService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShiroServiceImpl implements ShiroService {

    @Autowired
    private ShiroDao mShiroDao;

    @Override
    public com.example.demo.entity.shiro.User findByEmail(String email) {
        return mShiroDao.findByEmail(email);
    }
}
