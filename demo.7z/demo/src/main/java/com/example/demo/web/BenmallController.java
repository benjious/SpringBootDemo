package com.example.demo.web;


import com.example.demo.entity.shiro.User;
import com.example.demo.util.LogUtil;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;


@Controller
@RequestMapping("/benmall")
public class BenmallController {

    private String tag = "benmallController  xyz ";
    private static String UPLOADED_FOLDER = "E://temp//";



    @RequestMapping(value = "/login")
    public String login(User user, HttpServletRequest request){

        LogUtil.getLogger(BenmallController.class).debug("邮箱："+user.getEmail());
        LogUtil.getLogger(BenmallController.class).debug("密码："+user.getPassword());
        Subject subject = SecurityUtils.getSubject();

        UsernamePasswordToken token = new UsernamePasswordToken(user.getEmail(), user.getPassword());
        try {
            subject.login(token);
            return "/index";
        } catch (UnknownAccountException e) {
            LogUtil.getLogger(BenmallController.class).error(" -- 没有该用户 -- ");
        } catch (IncorrectCredentialsException e) {
            LogUtil.getLogger(BenmallController.class).error(" -- 密码不正确 -- ");

        }catch (Exception e) {
            LogUtil.getLogger(BenmallController.class).error(" -- 其他错误信息： -- "+e.toString());
        }

        return "/login";
    }

    @RequestMapping("/index")
    public String index(){
        return "index";
    }

    @RequestMapping("/403")
    public String unauth(){
        return "unauthorization";
    }

    @RequestMapping("/admin")
    public String admin(){
        return "admin";
    }

    @RequestMapping("/guest")
    public String guest(){
        return "guest";
    }

    @RequestMapping("/logout")
    public String logout(){
        //todo
        return "logout";
    }


    @RequestMapping("/perupload")
    public String upload(){
        return "perUpload";
    }

    @RequestMapping("/uploadStatus")
    public String uploadStatus(){
        return "uploadStatus";
    }


    @RequestMapping("/upload")
    public String singleFileUpload(@RequestParam("file")MultipartFile file, RedirectAttributes attributes){
        if (file.isEmpty()) {
            attributes.addFlashAttribute("message", "Please select a file to upload");
            return "redirect:/benmalluploadStatus";
        }
        try {
            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

            attributes.addFlashAttribute("message",
                    "You successfully uploaded '" + file.getOriginalFilename() + "'");

        } catch (IOException e) {
            e.printStackTrace();
        }

        return "redirect:/benmall/uploadStatus";
    }


}
