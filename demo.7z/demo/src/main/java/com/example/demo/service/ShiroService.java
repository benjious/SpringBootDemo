package com.example.demo.service;

import com.example.demo.entity.shiro.User;

public interface ShiroService {
    User findByEmail(String email);
}
