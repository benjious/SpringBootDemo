package com.example.demo.dao.seckill;


import com.example.demo.entity.seckill.SuccessKilled;

import org.apache.ibatis.annotations.Param;

public interface SuccessKilledDao {
    int insertSuccessKill(@Param("seckillId") long seckillId, @Param("userPhone") long userPhone);
   SuccessKilled querySuccessSeckillById(@Param("seckillId") long seckillId, @Param("userPhone") long userPhone);

}
