package com.example.demo.dao.shiro;
import com.example.demo.entity.shiro.SysRole;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ShiroDao {
    List<SysRole> findRolesByUserId(@Param("userId") int userId);
    com.example.demo.entity.shiro.User findByEmail(@Param("email") String email);
}
