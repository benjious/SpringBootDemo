package com.example.demo.controller;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@ComponentScan(value = {"com.example.demo.controller"})
@RestController
public class HelloWorldController {
    @RequestMapping("/hello")
    public String index(){
        return "hello world";
    }
}
